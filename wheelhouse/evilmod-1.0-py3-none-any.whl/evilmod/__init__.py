# importable stand-in for the hijacked dependency
